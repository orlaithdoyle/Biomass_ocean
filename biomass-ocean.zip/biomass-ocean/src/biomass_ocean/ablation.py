import numpy as np
import pandas as pd
from scipy import stats
from tqdm.auto import tqdm


def demean(df, cols, group="pass_id"):
    return df[cols] - df.groupby(group)[cols].transform("mean")


def _fit(X, y, ridge=1e-6):
    X1 = np.column_stack([X, np.ones(len(X))])
    A = X1.T @ X1 + ridge * np.eye(X1.shape[1])
    return np.linalg.solve(A, X1.T @ y)


def _pred(beta, X):
    return np.column_stack([X, np.ones(len(X))]) @ beta


def lopo(df, features, target="sss", group="pass_id", passes=None):
    # SMOS pass mean + within-pass anomaly regression, leave one pass out.
    # baseline = the pass mean alone, so skill only counts within-pass structure
    d = df.dropna(subset=list(features) + [target]).copy()
    if passes is not None:
        d = d[d[group].isin(passes)]
    Xa = demean(d, list(features), group).values
    sd = Xa.std(0)
    sd[sd == 0] = 1
    Xa = Xa / sd
    ya = demean(d, [target], group).values.ravel()
    base = d.groupby(group)[target].transform("mean").values
    pa = np.full(len(d), np.nan)
    gid = d[group].values
    for p in np.unique(gid):
        tr, te = gid != p, gid == p
        pa[te] = _pred(_fit(Xa[tr], ya[tr]), Xa[te])
        pa[te] -= pa[te].mean()  # anomaly only, the pass mean comes from SMOS
    y = d[target].values
    yhat = base + pa
    per = []
    for p in np.unique(gid):
        s = gid == p
        per.append(dict(pass_id=p, n=int(s.sum()),
                        rmse_model=np.sqrt(np.mean((y[s] - yhat[s]) ** 2)),
                        rmse_base=np.sqrt(np.mean((y[s] - base[s]) ** 2))))
    per = pd.DataFrame(per)
    per["improved"] = per["rmse_model"] < per["rmse_base"]
    rm = np.sqrt(np.mean((y - yhat) ** 2))
    rb = np.sqrt(np.mean((y - base) ** 2))
    out = dict(features="+".join(features), n_cells=len(d), n_passes=len(per),
               skill=1 - (rm / rb) ** 2, r=np.corrcoef(pa, ya)[0, 1], rmse=rm, rmse_base=rb,
               passes_improved=int(per["improved"].sum()),
               p_sign=stats.binomtest(int(per["improved"].sum()), len(per), 0.5, "greater").pvalue)
    return out, per, pd.Series(yhat, index=d.index)


def ablation(df, sets, target="sss", group="pass_id", passes=None):
    # same procedure, different inputs; if the skill survives without the radar it isn't the radar
    rows = []
    for name, feats in tqdm(sets.items(), desc="ablation"):
        o, _, _ = lopo(df, feats, target, group, passes)
        o["set"] = name
        rows.append(o)
    cols = ["set", "skill", "r", "rmse", "rmse_base", "passes_improved", "n_passes", "p_sign", "n_cells", "features"]
    return pd.DataFrame(rows)[cols]


def circular_shift_null(df, features, target="sss", group="pass_id", passes=None, n=200, seed=0):
    # NB: this null keeps smooth along-track structure, so it does NOT catch geography/sea-state proxies
    rng = np.random.default_rng(seed)
    obs = lopo(df, features, target, group, passes)[0]["skill"]
    d = df.sort_values([group, "along_km"]).copy()
    null = []
    for _ in tqdm(range(n), desc="shift null", leave=False):
        sh = d.copy()
        for p, idx in sh.groupby(group).groups.items():
            v = sh.loc[idx, target].values
            sh.loc[idx, target] = np.roll(v, rng.integers(1, max(2, len(v))))
        null.append(lopo(sh, features, target, group, passes)[0]["skill"])
    null = np.array(null)
    return obs, null, (1 + (null >= obs).sum()) / (1 + n)


def partial_r(df, x, y, controls=(), group="pass_id"):
    # within-pass correlation of x and y after removing pooled linear effect of the controls
    cols = [x, y] + list(controls)
    d = df.dropna(subset=cols)
    a = demean(d, cols, group)
    if controls:
        C = a[list(controls)].values
        for v in (x, y):
            a[v] = a[v] - _pred(_fit(C, a[v].values), C)
    return np.corrcoef(a[x], a[y])[0, 1], len(d)


def shuffle_null(df, x, y, controls=(), group="pass_id", n=1000, seed=0):
    rng = np.random.default_rng(seed)
    obs, _ = partial_r(df, x, y, controls, group)
    d = df.dropna(subset=[x, y] + list(controls)).copy()
    null = np.empty(n)
    for i in tqdm(range(n), desc="shuffle null", leave=False):
        d[x] = d.groupby(group)[x].transform(lambda s: rng.permutation(s.values))
        null[i] = partial_r(d, x, y, controls, group)[0]
    p = (1 + (np.abs(null) >= abs(obs)).sum()) / (1 + n)
    return obs, np.percentile(null, [2.5, 97.5]), p


def proxy_check(df, a, b, group="pass_id"):
    # how well one smooth field (e.g. ERA5 swell) tracks another (latitude) inside each pass
    out = []
    for p, d in df.dropna(subset=[a, b]).groupby(group):
        if len(d) > 2:
            out.append(dict(pass_id=p, n=len(d), r=np.corrcoef(d[a], d[b])[0, 1]))
    return pd.DataFrame(out)


def contrast_passes(df, target="sss", min_range=3.0, group="pass_id"):
    rng = df.groupby(group)[target].agg(lambda s: s.max() - s.min())
    return rng[rng >= min_range].index.tolist()
