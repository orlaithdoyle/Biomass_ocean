from pathlib import Path
import warnings
import numpy as np
import rasterio
from rasterio.windows import Window
from lxml import etree
from scipy.interpolate import LinearNDInterpolator, NearestNDInterpolator

from .search import parse_id

DEFAULT_ORDER = ["HH", "HV", "VH", "VV"]
BAD_QUALITY_BITS = (5, 10, 11)


def find_products(root, ptype="SCS"):
    # folder layouts differ between archives (Amazon vs El Nino), so search instead of building paths
    out = {}
    for p in Path(root).rglob(f"BIO_*_{ptype}__1S_*"):
        if p.is_dir() and (p / "measurement").is_dir():
            out[p.name] = p
    return sorted(out.values(), key=lambda p: p.name)


def tiffs(pdir):
    m = Path(pdir) / "measurement"
    amp = sorted(m.glob("*_i_abs.tif*"))
    pha = sorted(m.glob("*_i_phase.tif*"))
    if not amp or not pha:
        raise FileNotFoundError(f"no i_abs / i_phase tiff in {m}")
    return amp[0], pha[0]


def _xml_values(pdir, tag):
    vals = []
    for x in Path(pdir).rglob("*.xml"):
        try:
            tree = etree.parse(str(x))
        except Exception:
            continue
        vals += [e.text for e in tree.xpath(f"//*[local-name()='{tag}']") if e.text]
    return vals


def orbit_pass(pdir):
    v = _xml_values(pdir, "orbitPass")
    return v[0].strip().capitalize() if v else None


def quality_ok(pdir):
    v = _xml_values(pdir, "overallProductQualityIndex")
    if not v:
        return None
    q = int(v[0])
    return all(not (q >> b) & 1 for b in BAD_QUALITY_BITS)


def band_order(tiff):
    # read polarisation per band from the tags; TIFF order is HH HV VH VV but never trust a hard-coded order
    order = {}
    with rasterio.open(tiff) as src:
        for b in range(1, src.count + 1):
            tags = {k.upper(): v for k, v in src.tags(b).items()}
            pol = tags.get("POLARIMETRIC_INTERP") or src.descriptions[b - 1]
            if pol:
                order[pol.strip().upper()] = b
    if len(order) < 4:
        warnings.warn(f"no POLARIMETRIC_INTERP tags in {Path(tiff).name}, falling back to {DEFAULT_ORDER}")
        order = {p: i + 1 for i, p in enumerate(DEFAULT_ORDER)}
    return order


def shape(tiff):
    with rasterio.open(tiff) as src:
        return src.height, src.width


def gcps(tiff):
    with rasterio.open(tiff) as src:
        g, _ = src.gcps
    if not g:
        raise ValueError(f"no GCPs in {tiff}")
    rows = np.array([p.row for p in g])
    cols = np.array([p.col for p in g])
    lon = np.array([p.x for p in g])
    lat = np.array([p.y for p in g])
    return rows, cols, lat, lon


def geolocate(tiff, rows, cols):
    # lat/lon at given pixel rows/cols (1-D each), linear inside the GCP hull, nearest outside
    r0, c0, lat, lon = gcps(tiff)
    pts = np.column_stack([r0, c0])
    # unwrap so a frame across the dateline interpolates cleanly
    lon_u = np.degrees(np.unwrap(np.radians(lon)))
    rr, cc = np.meshgrid(rows, cols, indexing="ij")
    q = np.column_stack([rr.ravel(), cc.ravel()])
    out = []
    for v in (lat, lon_u):
        lin = LinearNDInterpolator(pts, v)(q)
        bad = ~np.isfinite(lin)
        if bad.any():
            lin[bad] = NearestNDInterpolator(pts, v)(q[bad])
        out.append(lin.reshape(rr.shape))
    lat_g, lon_g = out
    lon_g = ((lon_g + 180) % 360) - 180
    return lat_g, lon_g


def latlon_grid(tiff, dec=1, coarse=64):
    # geolocate a coarse grid from the GCPs, then bilinear up to the full (decimated) grid; far cheaper than per pixel
    from scipy.interpolate import RegularGridInterpolator
    h, w = shape(tiff)
    rc = np.unique(np.r_[np.arange(0, h, coarse), h - 1])
    cc = np.unique(np.r_[np.arange(0, w, coarse), w - 1])
    lat_c, lon_c = geolocate(tiff, rc, cc)
    lon_c = np.degrees(np.unwrap(np.unwrap(np.radians(lon_c), axis=0), axis=1))
    rows, cols = np.arange(0, h, dec), np.arange(0, w, dec)
    rr, cc2 = np.meshgrid(rows, cols, indexing="ij")
    q = np.column_stack([rr.ravel(), cc2.ravel()])
    lat = RegularGridInterpolator((rc, cc), lat_c)(q).reshape(rr.shape)
    lon = RegularGridInterpolator((rc, cc), lon_c)(q).reshape(rr.shape)
    return lat, ((lon + 180) % 360) - 180


def read_bands(tiff, pols, row0=0, nrows=None, dec=1):
    order = band_order(tiff)
    h, w = shape(tiff)
    nrows = h - row0 if nrows is None else min(nrows, h - row0)
    with rasterio.open(tiff) as src:
        win = Window(0, row0, w, nrows)
        return {p: src.read(order[p], window=win)[::dec, ::dec].astype(np.float32) for p in pols}


def read_complex(pdir, pols=("HH", "VV"), row0=0, nrows=None, dec=1):
    amp_t, pha_t = tiffs(pdir)
    a = read_bands(amp_t, pols, row0, nrows, dec)
    p = read_bands(pha_t, pols, row0, nrows, dec)
    return {k: a[k] * np.exp(1j * p[k]) for k in pols}


def info(pdir):
    pdir = Path(pdir)
    d = parse_id(pdir.name) or {}
    d["path"] = pdir
    d["orbit_pass"] = orbit_pass(pdir)
    d["quality_ok"] = quality_ok(pdir)
    return d
