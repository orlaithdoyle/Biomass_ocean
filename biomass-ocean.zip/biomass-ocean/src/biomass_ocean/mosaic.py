from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from tqdm.auto import tqdm

from .search import parse_id
from .cpd import ocean_cpd, colour_limits, _cmap, DEC
from .utils import savefig


def group_passes(product_dirs):
    # one pass = same date, track and swath; frames sorted along track
    g = defaultdict(list)
    for p in product_dirs:
        d = parse_id(Path(p).name)
        if d:
            g[(d["date"], d["track"], d["swath"])].append((d["frame"], Path(p)))
    return {k: [p for _, p in sorted(v)] for k, v in sorted(g.items())}


def process_pass(product_dirs, dec=DEC):
    res = []
    for p in tqdm(product_dirs, desc="frames"):
        res.append(ocean_cpd(p, dec=dec, progress=False))
    return res


def plot_pass(res, out_dir, key=None, stride=4, show=True, extra_ax=None):
    # every frame drawn on its own lon/lat grid, colour limits pooled over the whole pass
    pooled = np.concatenate([r["phi"][np.isfinite(r["phi"])] for r in res])
    if pooled.size == 0:
        print("no ocean pixels in pass")
        return None
    c, s, (vmin, vmax) = colour_limits(pooled)
    fig, ax = plt.subplots(figsize=(7, 10)) if extra_ax is None else (extra_ax.figure, extra_ax)
    for r in res:
        sl = (slice(None, None, stride), slice(None, None, stride))
        im = ax.pcolormesh(r["lon"][sl], r["lat"][sl], np.ma.masked_invalid(r["phi"][sl]),
                           cmap=_cmap(), vmin=vmin, vmax=vmax, shading="nearest", rasterized=True)
    ax.set_aspect(1 / np.cos(np.radians(np.nanmean(res[0]["lat"]))))
    ax.xaxis.set_major_locator(plt.MaxNLocator(3))
    ax.set_xlabel("Longitude (°)")
    ax.set_ylabel("Latitude (°)")
    r0 = res[0]
    key = key or (r0["date"], r0["track"], r0["swath"])
    ax.set_title(f"{key[0]} T{key[1]:03d} {key[2]}  HH-VV phase, mean {c:.3f}, σ {s:.3f} rad")
    fig.colorbar(im, ax=ax, label="HH-VV phase (rad)", shrink=0.7)
    if extra_ax is None:
        out = Path(out_dir) / f"cpd_pass_{key[0].replace('-', '')}_T{key[1]:03d}_{key[2]}.png"
        savefig(fig, out)
        plt.show() if show else plt.close(fig)
        return out
    return ax
