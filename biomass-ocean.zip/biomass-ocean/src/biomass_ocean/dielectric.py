import numpy as np

F_BIOMASS = 435e6
EPS0 = 8.854e-12


def klein_swift(sss, sst, f=F_BIOMASS):
    # Klein & Swift (1977) sea water permittivity, eps = eps' - j eps'' (their sign convention)
    S, T = np.asarray(sss, float), np.asarray(sst, float)
    w = 2 * np.pi * f
    eps_inf = 4.9
    es_t = 87.134 - 1.949e-1 * T - 1.276e-2 * T**2 + 2.491e-4 * T**3
    a = 1.0 + 1.613e-5 * T * S - 3.656e-3 * S + 3.210e-5 * S**2 - 4.232e-7 * S**3
    tau_t = 1.768e-11 - 6.086e-13 * T + 1.104e-14 * T**2 - 8.111e-17 * T**3
    b = 1.0 + 2.282e-5 * T * S - 7.638e-4 * S - 7.760e-6 * S**2 + 1.105e-8 * S**3
    d = 25.0 - T
    sig25 = S * (0.182521 - 1.46192e-3 * S + 2.09324e-5 * S**2 - 1.28205e-7 * S**3)
    beta = 2.033e-2 + 1.266e-4 * d + 2.464e-6 * d**2 - S * (1.849e-5 - 2.551e-7 * d + 2.551e-8 * d**2)
    sigma = sig25 * np.exp(-d * beta)
    es, tau = es_t * a, tau_t * b
    return eps_inf + (es - eps_inf) / (1 + 1j * w * tau) - 1j * sigma / (w * EPS0)


def fresnel(eps, theta_deg):
    th = np.radians(theta_deg)
    c, s2 = np.cos(th), np.sin(th) ** 2
    r = np.sqrt(eps - s2)
    rh = (c - r) / (c + r)
    rv = (eps * c - r) / (eps * c + r)
    return rh, rv


def bragg_coeffs(eps, theta_deg):
    th = np.radians(theta_deg)
    c, s2 = np.cos(th), np.sin(th) ** 2
    r = np.sqrt(eps - s2)
    g_hh = (eps - 1) / (c + r) ** 2
    g_vv = (eps - 1) * (eps * (1 + s2) - s2) / (eps * c + r) ** 2
    return g_hh, g_vv
