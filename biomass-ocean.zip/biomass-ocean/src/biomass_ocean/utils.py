from pathlib import Path
import numpy as np
from scipy.ndimage import uniform_filter


def nan_uniform(x, size):
    # NaN-safe box filter: plain uniform_filter spreads NaN from masked land and
    # mode='reflect' inflates pixels next to the edge
    m = np.isfinite(x)
    num = uniform_filter(np.where(m, x, 0.0), size, mode="constant")
    den = uniform_filter(m.astype(float), size, mode="constant")
    with np.errstate(invalid="ignore", divide="ignore"):
        out = num / den
    out[den < 1e-6] = np.nan
    return out


def nan_uniform_complex(z, size):
    return nan_uniform(z.real, size) + 1j * nan_uniform(z.imag, size)


def block_mean(x, az, rg):
    # multilook by az x rg blocks, NaN-safe; works for complex too
    h, w = x.shape
    h2, w2 = h // az * az, w // rg * rg
    b = x[:h2, :w2].reshape(h2 // az, az, w2 // rg, rg)
    if np.iscomplexobj(b):
        m = np.isfinite(b.real)
        s = np.where(m, b, 0).sum(axis=(1, 3))
    else:
        m = np.isfinite(b)
        s = np.where(m, b, 0).sum(axis=(1, 3))
    n = m.sum(axis=(1, 3))
    with np.errstate(invalid="ignore", divide="ignore"):
        out = s / n
    out[n == 0] = np.nan
    return out


def wrap(phi):
    return np.angle(np.exp(1j * phi))


def circ_mean(phi, axis=None):
    return np.angle(np.nanmean(np.exp(1j * phi), axis=axis))


def circ_std(phi, axis=None):
    r = np.abs(np.nanmean(np.exp(1j * phi), axis=axis))
    return np.sqrt(-2 * np.log(np.clip(r, 1e-12, 1)))


def zscore(x):
    return (x - np.nanmean(x)) / np.nanstd(x)


def outdir(*parts):
    p = Path(*parts)
    p.mkdir(parents=True, exist_ok=True)
    return p


def savefig(fig, path, dpi=200):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    return path
