import numpy as np
from global_land_mask import globe


def is_ocean(lat, lon):
    lat = np.clip(np.asarray(lat, float), -90, 90)
    lon = ((np.asarray(lon, float) + 180) % 360) - 180
    out = np.zeros(lat.shape, bool)
    ok = np.isfinite(lat) & np.isfinite(lon)
    out[ok] = globe.is_ocean(lat[ok], lon[ok])
    return out


def ocean_fraction(lat, lon):
    return float(is_ocean(lat, lon).mean())
