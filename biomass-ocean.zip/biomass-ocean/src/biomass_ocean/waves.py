import numpy as np
from scipy.constants import c as C_LIGHT
from scipy.integrate import trapezoid

from .dielectric import klein_swift, bragg_coeffs, F_BIOMASS
from .utils import savefig

G0 = 9.81  # never call this g, it gets overwritten by loop variables in notebooks
CM, KM = 0.23, 370.0


def k_radar(f=F_BIOMASS):
    return 2 * np.pi * f / C_LIGHT


def k_bragg(theta_deg, f=F_BIOMASS):
    return 2 * k_radar(f) * np.sin(np.radians(theta_deg))


def phase_speed(k):
    return np.sqrt(G0 / k * (1 + (k / KM) ** 2))


def friction_velocity(u10):
    cd = (0.8 + 0.065 * u10) * 1e-3
    return np.sqrt(cd) * u10


def elfouhaily(k, u10, omega=0.84):
    # Elfouhaily et al. (1997) omnidirectional elevation spectrum S(k) [m^3] and spreading Delta(k)
    k = np.asarray(k, float)
    k0 = G0 / u10**2
    kp = k0 * omega**2
    cp = np.sqrt(G0 / kp)
    c = phase_speed(k)
    us = friction_velocity(u10)
    gamma = 1.7 if omega <= 1 else 1.7 + 6 * np.log10(omega)
    sig = 0.08 * (1 + 4 * omega**-3)
    Gam = np.exp(-((np.sqrt(k / kp) - 1) ** 2) / (2 * sig**2))
    Jp = gamma**Gam
    Lpm = np.exp(-1.25 * (kp / k) ** 2)
    ap = 6e-3 * np.sqrt(omega)
    Fp = Lpm * Jp * np.exp(-omega / np.sqrt(10) * (np.sqrt(k / kp) - 1))
    Bl = 0.5 * ap * (cp / c) * Fp
    am = 1e-2 * (1 + np.log(us / CM)) if us < CM else 1e-2 * (1 + 3 * np.log(us / CM))
    Fm = Lpm * Jp * np.exp(-0.25 * (k / KM - 1) ** 2)
    Bh = 0.5 * am * (CM / c) * Fm
    S = (Bl + Bh) / k**3
    a0 = np.log(2) / 4
    delta = np.tanh(a0 + 4 * (c / cp) ** 2.5 + 0.13 * us / CM * (CM / c) ** 2.5)
    return S, delta


def directional(k, phi, u10, omega=0.84):
    # Psi(k, phi) with integral of Psi k dk dphi = elevation variance; phi relative to the wind
    S, d = elfouhaily(k, u10, omega)
    return S / k * (1 + d * np.cos(2 * phi)) / (2 * np.pi)


def bragg_sigma0(theta_deg, u10, sss=35.0, sst=20.0, phi_wind=0.0, f=F_BIOMASS, omega=0.84):
    # first-order small perturbation, linear units; phi_wind = look direction relative to the wind
    k0 = k_radar(f)
    kb = k_bragg(theta_deg, f)
    eps = klein_swift(sss, sst, f)
    ghh, gvv = bragg_coeffs(eps, theta_deg)
    psi = directional(kb, phi_wind, u10, omega)
    pre = 16 * np.pi * k0**4 * np.cos(np.radians(theta_deg)) ** 4
    return pre * np.abs(ghh) ** 2 * psi, pre * np.abs(gvv) ** 2 * psi, np.angle(ghh * np.conj(gvv))


def mss_range(u10, kmax, phi_wind=0.0, omega=0.84, n=4000):
    # slope variance in the look direction from waves longer than kmax
    k = np.logspace(-3, np.log10(kmax), n)
    S, d = elfouhaily(k, u10, omega)
    return trapezoid(k**2 * S * (0.5 + 0.25 * d * np.cos(2 * phi_wind)), k)


def tilted_bragg(theta_deg, u10, sss=35.0, sst=20.0, phi_wind=0.0, f=F_BIOMASS, omega=0.84, n=81):
    # Bragg averaged over Gaussian long-wave tilts in the incidence plane (azimuth tilts ignored)
    if np.ndim(theta_deg):
        out = [tilted_bragg(t, u10, sss, sst, phi_wind, f, omega, n) for t in np.ravel(theta_deg)]
        return np.array([o[0] for o in out]), np.array([o[1] for o in out])
    kb = k_bragg(theta_deg, f)
    s = np.sqrt(mss_range(u10, kb / 3, phi_wind, omega))
    t = np.linspace(-4 * s, 4 * s, n)
    w = np.exp(-0.5 * (t / s) ** 2)
    w /= w.sum()
    hh = vv = 0.0
    for ti, wi in zip(t, w):
        th = theta_deg - np.degrees(np.arctan(ti))
        a, b, _ = bragg_sigma0(th, u10, sss, sst, phi_wind, f, omega)
        hh = hh + wi * a
        vv = vv + wi * b
    return hh, vv


def db(x):
    return 10 * np.log10(x)


def image_spectrum(img, dx, dy, detrend=True):
    # 2-D power spectrum of a normalised intensity patch, Hann windowed; returns kx, ky (rad/m) and P
    x = img / np.nanmean(img) - 1
    x = np.where(np.isfinite(x), x, 0)
    if detrend:
        x = x - x.mean()
    win = np.outer(np.hanning(x.shape[0]), np.hanning(x.shape[1]))
    F = np.fft.fftshift(np.fft.fft2(x * win))
    ky = np.fft.fftshift(np.fft.fftfreq(x.shape[0], dy)) * 2 * np.pi
    kx = np.fft.fftshift(np.fft.fftfreq(x.shape[1], dx)) * 2 * np.pi
    return kx, ky, np.abs(F) ** 2


def sublooks(slc, n=2, axis=0):
    # split the azimuth spectrum into n non-overlapping looks
    F = np.fft.fftshift(np.fft.fft(np.nan_to_num(slc), axis=axis), axes=axis)
    m = F.shape[axis] // n
    out = []
    for i in range(n):
        G = np.zeros_like(F)
        sl = [slice(None)] * F.ndim
        sl[axis] = slice(i * m, (i + 1) * m)
        G[tuple(sl)] = F[tuple(sl)]
        out.append(np.abs(np.fft.ifft(np.fft.ifftshift(G, axes=axis), axis=axis)) ** 2)
    return out


def cross_spectrum(a, b, dx, dy):
    # look cross-spectrum; the imaginary part resolves the 180 degree direction ambiguity
    def prep(z):
        z = z / np.nanmean(z) - 1
        z = np.where(np.isfinite(z), z, 0)
        return (z - z.mean()) * np.outer(np.hanning(z.shape[0]), np.hanning(z.shape[1]))
    Fa = np.fft.fftshift(np.fft.fft2(prep(a)))
    Fb = np.fft.fftshift(np.fft.fft2(prep(b)))
    ky = np.fft.fftshift(np.fft.fftfreq(a.shape[0], dy)) * 2 * np.pi
    kx = np.fft.fftshift(np.fft.fftfreq(a.shape[1], dx)) * 2 * np.pi
    return kx, ky, Fa * np.conj(Fb)


def spectral_peak(kx, ky, P, kmin=2 * np.pi / 1000, kmax=2 * np.pi / 50):
    KX, KY = np.meshgrid(kx, ky)
    K = np.hypot(KX, KY)
    m = (K >= kmin) & (K <= kmax)
    i = np.argmax(np.where(m, P, -np.inf))
    k = K.flat[i]
    return dict(wavelength_m=2 * np.pi / k, direction_deg=np.degrees(np.arctan2(KY.flat[i], KX.flat[i])) % 360)


def plot_spectrum(kx, ky, P, out_png, kmax=2 * np.pi / 50, show=True):
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.pcolormesh(kx, ky, 10 * np.log10(P + 1e-12), shading="auto", cmap="viridis")
    ax.set_xlim(-kmax, kmax)
    ax.set_ylim(-kmax, kmax)
    ax.set_aspect("equal")
    ax.set_xlabel("k range (rad/m)")
    ax.set_ylabel("k azimuth (rad/m)")
    fig.colorbar(im, label="power (dB)")
    savefig(fig, out_png)
    plt.show() if show else plt.close(fig)
