from pathlib import Path
from urllib.parse import urlparse
import requests
from tqdm.auto import tqdm

SKIP_ROLES = {"thumbnail", "overview"}


def local_path(href, out_dir):
    # keep the product folder layout below the yyyy/mm/dd part of the URL
    parts = urlparse(href).path.strip("/").split("/")
    for i, p in enumerate(parts):
        if p.startswith("BIO_"):
            return Path(out_dir).joinpath(*parts[i:])
    return Path(out_dir) / parts[-1]


def asset_list(item, keys=None):
    out = []
    for k, a in item.assets.items():
        if keys and k not in keys:
            continue
        if SKIP_ROLES & set(a.roles or []):
            continue
        if not a.href.startswith("http"):
            continue
        out.append((k, a.href))
    return out


def fetch(url, dest, token, chunk=1 << 20):
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    with requests.get(url, headers=token.headers(), stream=True, timeout=120) as r:
        r.raise_for_status()
        total = int(r.headers.get("content-length", 0))
        with open(tmp, "wb") as f, tqdm(total=total, unit="B", unit_scale=True,
                                         desc=dest.name[:40], leave=False) as bar:
            for b in r.iter_content(chunk):
                f.write(b)
                bar.update(len(b))
    tmp.replace(dest)


def download_items(items, token, out_dir, keys=None, overwrite=False):
    out_dir = Path(out_dir)
    done, skipped, failed = 0, 0, []
    for item in tqdm(items, desc="products"):
        for k, href in asset_list(item, keys):
            dest = local_path(href, out_dir)
            if dest.exists() and dest.stat().st_size > 0 and not overwrite:
                skipped += 1
                continue
            try:
                fetch(href, dest, token)
                done += 1
            except Exception as e:
                failed.append((item.id, k, str(e)[:120]))
    print(f"downloaded {done}, already on disk {skipped}, failed {len(failed)}")
    for f in failed[:10]:
        print("  ", f)
    return failed
