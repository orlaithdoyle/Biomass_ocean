import json
import time
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.path import Path as MPath
from tqdm.auto import tqdm

from .search import client, parse_id, L1A
from .landmask import is_ocean
from .utils import savefig

def month_windows(start, end):
    # monthly windows keep each query far below the 100k record cap
    s = pd.Timestamp(start).to_period("M")
    e = pd.Timestamp(end).to_period("M")
    return [(str(p.start_time.date()), str((p.end_time).date())) for p in pd.period_range(s, e, freq="M")]


def footprint_points(geom, n=15):
    if geom["type"] == "MultiPolygon":
        rings = [np.array(p[0]) for p in geom["coordinates"]]
        ring = max(rings, key=len)
    else:
        ring = np.array(geom["coordinates"][0])
    lon = np.degrees(np.unwrap(np.radians(ring[:, 0])))
    ring = np.column_stack([lon, ring[:, 1]])
    gx, gy = np.meshgrid(np.linspace(lon.min(), lon.max(), n), np.linspace(ring[:, 1].min(), ring[:, 1].max(), n))
    pts = np.column_stack([gx.ravel(), gy.ravel()])
    inside = MPath(ring).contains_points(pts)
    pts = pts[inside] if inside.any() else ring
    return pts[:, 1], ((pts[:, 0] + 180) % 360) - 180


def classify(f_ocean, ocean=0.95, land=0.05):
    return "ocean" if f_ocean >= ocean else "land" if f_ocean <= land else "coastal"


def _row(item):
    p = parse_id(item.id) or {}
    g = item.properties.get("grid:code") or f"T{p.get('track', 0):03d}_F{p.get('frame', 0):03d}_{p.get('swath')}"
    lat, lon = footprint_points(item.geometry)
    fo = float(is_ocean(lat, lon).mean())
    return dict(grid_code=g, id=item.id, date=p.get("date"), swath=p.get("swath"), track=p.get("track"),
                frame=p.get("frame"), ptype=p.get("ptype"), lat=float(np.mean(lat)), lon=float(np.mean(lon)),
                ocean_frac=fo, cls=classify(fo))


def scan(out_dir, start="2025-05-01", end=None, collection=L1A, max_retries=20):
    # resumable: finished months are recorded in scan_state.json, rows in a CSV checkpoint
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    csv, state_f = out / "swaths_all.csv", out / "scan_state.json"
    state = json.loads(state_f.read_text()) if state_f.exists() else {"done": [], "n_granules": 0}
    seen = set(pd.read_csv(csv)["grid_code"]) if csv.exists() else set()
    end = end or str(pd.Timestamp.today().date())

    for w in tqdm(month_windows(start, end), desc="months"):
        if f"{w[0]}/{w[1]}" in state["done"]:
            continue
        for attempt in range(max_retries):
            rows, seen_m = [], set(seen)
            try:
                it = client().search(collections=[collection], datetime=f"{w[0]}/{w[1]}").items()
                for item in tqdm(it, desc=w[0][:7], leave=False):
                    r = _row(item)
                    r["repeat"] = r["grid_code"] in seen_m
                    seen_m.add(r["grid_code"])
                    rows.append(r)
                break
            except Exception as e:
                # an API error is not the end of the collection; reconnect and redo the month
                print(f"{w}: {type(e).__name__} {str(e)[:80]}, retry {attempt + 1}")
                time.sleep(min(60, 5 * (attempt + 1)))
        else:
            print("gave up on", w)
            continue
        # checkpoint once per finished month so a crash never leaves half a month in the CSV
        if rows:
            pd.DataFrame(rows).to_csv(csv, mode="a", header=not csv.exists(), index=False)
        seen = seen_m
        state["n_granules"] += len(rows)
        state["done"].append(f"{w[0]}/{w[1]}")
        state_f.write_text(json.dumps(state))
    print(f"{state['n_granules']} granules, {len(seen)} unique swath locations")
    return unique_swaths(csv)


def unique_swaths(csv):
    df = pd.read_csv(csv)
    first = df.sort_values("date").drop_duplicates("grid_code")
    visits = df.groupby("grid_code").size().rename("visits")
    return first.drop(columns=["repeat"], errors="ignore").merge(visits, on="grid_code")


def plot_world(sw, out_png, show=True):
    lat = np.linspace(-90, 90, 721)
    lon = np.linspace(-180, 180, 1441)
    LO, LA = np.meshgrid(lon, lat)
    land = ~is_ocean(LA, LO)
    fig, ax = plt.subplots(figsize=(14, 7))
    ax.imshow(land, origin="lower", extent=[-180, 180, -90, 90], cmap="Greys", vmin=0, vmax=3, alpha=0.6)
    for c, col in (("ocean", "tab:blue"), ("coastal", "tab:orange"), ("land", "tab:green")):
        s = sw[sw["cls"] == c]
        ax.scatter(s["lon"], s["lat"], s=4, c=col, label=f"{c} ({len(s)})")
    ax.set_xlim(-180, 180)
    ax.set_ylim(-90, 90)
    ax.set_xlabel("Longitude (°)")
    ax.set_ylabel("Latitude (°)")
    ax.set_title(f"BIOMASS L1a unique swath locations: {len(sw)}")
    ax.legend(loc="lower left", markerscale=3)
    savefig(fig, out_png)
    plt.show() if show else plt.close(fig)


def discovery_curve(csv, out_png, show=True):
    df = pd.read_csv(csv).sort_values("date")
    new = ~df["grid_code"].duplicated()
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(np.arange(len(df)), new.cumsum())
    ax.set_xlabel("granules scanned")
    ax.set_ylabel("unique swath locations")
    savefig(fig, out_png)
    plt.show() if show else plt.close(fig)
