from pathlib import Path
import time
import requests

TOKEN_URL = "https://iam.maap.eo.esa.int/realms/esa-maap/protocol/openid-connect/token"

_ALIASES = {
    "offline_token": ["OFFLINE_TOKEN", "maap_offline_token"],
    "client_id": ["CLIENT_ID", "maap_client_id"],
    "client_secret": ["CLIENT_SECRET", "maap_client_secret"],
}


def read_credentials(path="eo_credentials.txt"):
    raw = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        raw[k.strip().lower()] = v.strip().strip('"').strip("'")
    creds = {}
    for key, names in _ALIASES.items():
        for n in names:
            if n.lower() in raw:
                creds[key] = raw[n.lower()]
                break
    missing = [k for k in _ALIASES if not creds.get(k)]
    if missing:
        raise ValueError(f"{path} is missing {missing}")
    return creds


class Token:
    # short-lived access token, refreshed from the offline token when close to expiry
    def __init__(self, creds):
        self.creds = creds
        self.value = None
        self.expires = 0

    def __call__(self):
        if self.value is None or time.time() > self.expires - 60:
            self.refresh()
        return self.value

    def refresh(self):
        data = {
            "grant_type": "refresh_token",
            "refresh_token": self.creds["offline_token"],
            "client_id": self.creds["client_id"],
            # client_secret has to be sent even with a refresh token, otherwise 401 unauthorized_client
            "client_secret": self.creds["client_secret"],
            "scope": "offline_access openid",
        }
        r = requests.post(TOKEN_URL, data=data, timeout=30)
        if r.status_code == 401 or r.status_code == 400:
            raise RuntimeError(
                f"MAAP token refused ({r.status_code}): {r.text[:200]}\n"
                "The offline token dies after 90 days or a quiet spell with no warning. "
                "Get a new one at https://portal.maap.eo.esa.int/ini/services/auth/token/"
            )
        r.raise_for_status()
        js = r.json()
        self.value = js["access_token"]
        self.expires = time.time() + js.get("expires_in", 300)
        return self.value

    def headers(self):
        return {"Authorization": f"Bearer {self()}"}


def login(path="eo_credentials.txt"):
    tok = Token(read_credentials(path))
    tok.refresh()
    return tok
