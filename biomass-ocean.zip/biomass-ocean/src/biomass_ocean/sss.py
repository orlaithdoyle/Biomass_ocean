from pathlib import Path
import numpy as np
import pandas as pd

from .utils import circ_mean

SMAP_SHORT_NAME = "SMAP_RSS_L3_SSS_SMI_8DAY-RUNNINGMEAN_V6"  # about a week of latency

# variable names per source; SMOS names differ between CATDS and BEC files, check yours with ncdump -h
SOURCES = {
    "smap": dict(var="sss_smap", lat="lat", lon="lon"),
    "smos": dict(var="SSS", lat="lat", lon="lon"),
    "cmems": dict(var="sos", lat="latitude", lon="longitude"),
    "glorys": dict(var="so", lat="latitude", lon="longitude"),
}


def fetch_smap(date, bbox, out_dir):
    import earthaccess
    earthaccess.login()  # username must be a plain string, not a tuple, if you pass one
    res = earthaccess.search_data(short_name=SMAP_SHORT_NAME, temporal=(date, date), bounding_box=tuple(bbox))
    if not res:
        print("no SMAP granule for", date)
        return []
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    return earthaccess.download(res[:1], str(out_dir))


def load_grid(path, source="smap", var=None):
    import netCDF4
    cfg = dict(SOURCES[source])
    if var:
        cfg["var"] = var
    with netCDF4.Dataset(path) as ds:
        # np.array(..., float) on a masked array keeps the fill values; filled() doesn't
        v = np.ma.filled(ds.variables[cfg["var"]][:], np.nan).astype(float)
        lat = np.ma.filled(ds.variables[cfg["lat"]][:], np.nan).astype(float)
        lon = np.ma.filled(ds.variables[cfg["lon"]][:], np.nan).astype(float)
    v = np.squeeze(v)
    if v.ndim == 3:
        v = v[0]
    if v.shape != (lat.size, lon.size) and v.shape == (lon.size, lat.size):
        v = v.T
    lon = ((lon + 180) % 360) - 180
    o = np.argsort(lon)
    v, lon = v[:, o], lon[o]
    if lat[0] > lat[-1]:
        lat, v = lat[::-1], v[::-1]
    v[(v < 0) | (v > 45)] = np.nan
    return dict(sss=v, lat=lat, lon=lon, source=source, path=str(path))


def sample(grid, lat, lon):
    # nearest grid value at points
    i = np.clip(np.searchsorted(grid["lat"], lat), 1, grid["lat"].size - 1)
    i -= (lat - grid["lat"][i - 1]) < (grid["lat"][i] - lat)
    j = np.clip(np.searchsorted(grid["lon"], lon), 1, grid["lon"].size - 1)
    j -= (lon - grid["lon"][j - 1]) < (grid["lon"][j] - lon)
    return grid["sss"][i, j]


def find_file(folder, date):
    if folder is None:
        return None
    key = date.replace("-", "")
    hits = sorted(Path(folder).rglob(f"*{key}*.nc"))
    return hits[0] if hits else None


def pick_sss(date, lat, lon, smos_dir=None, smap_dir=None):
    # SMOS first, SMAP if SMOS has nothing over the scene
    for folder, src in ((smos_dir, "smos"), (smap_dir, "smap")):
        f = find_file(folder, date)
        if f is None:
            continue
        g = load_grid(f, src)
        if np.isfinite(sample(g, np.ravel(lat)[::500], np.ravel(lon)[::500])).any():
            return g
    return None


def cell_table(res, grid, cell=0.25, min_pix=50, extra=()):
    # per-product ocean pixels binned to cell x cell degree boxes (circular mean phase), SSS at the box centre
    rows = []
    for r in res:
        m = np.isfinite(r["phi"])
        if not m.any():
            continue
        la, lo, ph = r["lat"][m], r["lon"][m], r["phi"][m]
        ex = {k: r[k][m] for k in extra}
        ci = np.floor(la / cell).astype(int)
        cj = np.floor(lo / cell).astype(int)
        key = ci * 100000 + cj
        for k in np.unique(key):
            s = key == k
            if s.sum() < min_pix:
                continue
            clat = (ci[s][0] + 0.5) * cell
            clon = (cj[s][0] + 0.5) * cell
            row = dict(pass_id=f"{r['date']}_T{r['track']:03d}_{r['swath']}", date=r["date"],
                       track=r["track"], frame=r["frame"], lat=clat, lon=clon, n=int(s.sum()),
                       cpd=circ_mean(ph[s]))
            for kk, vv in ex.items():
                row[kk] = np.nanmean(vv[s])
            rows.append(row)
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    # a frame boundary can split a cell, merge those
    agg = {c: "mean" for c in df.columns if c not in ("pass_id", "date", "track", "lat", "lon", "n", "frame", "cpd")}
    df["z"] = np.exp(1j * df["cpd"]) * df["n"]
    g = df.groupby(["pass_id", "date", "track", "lat", "lon"], as_index=False)
    out = g.agg(n=("n", "sum"), z=("z", "sum"), frame=("frame", "min"), **{k: (k, v) for k, v in agg.items()})
    out["cpd"] = np.angle(out.pop("z"))
    out["sss"] = sample(grid, out["lat"].values, out["lon"].values)
    out["sss_source"] = grid["source"]
    return add_along_track(out)


def add_along_track(df):
    # position along the pass in km, from the main axis of the cell centres
    df = df.copy()
    df["along_km"] = np.nan
    for pid, d in df.groupby("pass_id"):
        y = (d["lat"] - d["lat"].mean()) * 111.0
        x = (d["lon"] - d["lon"].mean()) * 111.0 * np.cos(np.radians(d["lat"].mean()))
        X = np.column_stack([x, y])
        if len(X) < 2:
            df.loc[d.index, "along_km"] = 0.0
            continue
        v = np.linalg.svd(X - X.mean(0), full_matrices=False)[2][0]
        if v[1] < 0:
            v = -v  # positive northward
        df.loc[d.index, "along_km"] = X @ v
    return df
