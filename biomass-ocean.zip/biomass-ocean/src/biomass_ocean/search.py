import re
from datetime import datetime
from tqdm.auto import tqdm

STAC_URL = "https://catalog.maap.eo.esa.int/catalogue/"
L1A = "BiomassLevel1a"

ID_RE = re.compile(
    r"BIO_(?P<swath>S\d)_(?P<ptype>[A-Z]{3})__1S_(?P<start>\d{8}T\d{6})_(?P<stop>\d{8}T\d{6})_"
    r"(?P<phase>[A-Z])_G(?P<cov>\d+)_M(?P<major>\d+)_C(?P<repeat>\d+)_T(?P<track>\d{3})_F(?P<frame>\d{3})_"
    r"(?P<baseline>\d{2})_(?P<tag>\w+)",
    re.IGNORECASE,
)


def parse_id(name):
    m = ID_RE.search(str(name))
    if not m:
        return None
    d = m.groupdict()
    d["swath"] = d["swath"].upper()
    d["ptype"] = d["ptype"].upper()
    d["start"] = datetime.strptime(d["start"], "%Y%m%dT%H%M%S")
    d["stop"] = datetime.strptime(d["stop"], "%Y%m%dT%H%M%S")
    d["date"] = d["start"].strftime("%Y-%m-%d")
    d["track"] = int(d["track"])
    d["frame"] = int(d["frame"])
    return d


def wrap_lon(lon):
    return ((lon + 180) % 360) - 180


def bbox_around(lat, lon, half=2.0):
    # MAAP rejects big boxes and anything outside -180..180
    lon = wrap_lon(lon)
    return [max(lon - half, -180), max(lat - half, -90), min(lon + half, 180), min(lat + half, 90)]


def client():
    from pystac_client import Client
    return Client.open(STAC_URL)


def search(bbox=None, start=None, end=None, ptype="SCS", swaths=None, ids=None,
           collection=L1A, max_items=None, progress=True):
    # no server-side product:type filter, it silently drops S2/S3 acquisitions
    kw = dict(collections=[collection], max_items=max_items)
    if ids:
        kw["ids"] = list(ids)
    if bbox:
        kw["bbox"] = bbox
    if start or end:
        kw["datetime"] = f"{start or '..'}/{end or '..'}"
    items = []
    it = client().search(**kw).items()
    for item in tqdm(it, desc="STAC", disable=not progress):
        p = parse_id(item.id)
        if p is None:
            continue
        if ptype and p["ptype"] != ptype.upper():
            continue
        if swaths and p["swath"] not in swaths:
            continue
        items.append(item)
    return items


def summary(items):
    import pandas as pd
    rows = []
    for it in items:
        p = parse_id(it.id)
        rows.append(dict(id=it.id, date=p["date"], swath=p["swath"], track=p["track"],
                         frame=p["frame"], baseline=p["baseline"],
                         orbit=it.properties.get("sat:orbit_state")))
    return pd.DataFrame(rows).sort_values(["date", "track", "frame"]).reset_index(drop=True)
