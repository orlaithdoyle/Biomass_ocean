from pathlib import Path
import numpy as np
import pandas as pd

VARS = ["10m_u_component_of_wind", "10m_v_component_of_wind",
        "significant_height_of_combined_wind_waves_and_swell", "significant_height_of_total_swell",
        "mean_wave_direction", "mean_wave_period"]


def fetch(date, bbox, out_nc, variables=VARS):
    # needs ~/.cdsapirc; bbox is [W, S, E, N]
    import cdsapi
    out_nc = Path(out_nc)
    if out_nc.exists():
        return out_nc
    out_nc.parent.mkdir(parents=True, exist_ok=True)
    w, s, e, n = bbox
    cdsapi.Client().retrieve("reanalysis-era5-single-levels", {
        "product_type": ["reanalysis"], "variable": variables,
        "year": date[:4], "month": date[5:7], "day": date[8:10],
        "time": [f"{h:02d}:00" for h in range(24)],
        "area": [n, w, s, e], "data_format": "netcdf",
    }, str(out_nc))
    return out_nc


def load(path):
    import netCDF4
    out = {}
    with netCDF4.Dataset(path) as ds:
        tname = "valid_time" if "valid_time" in ds.variables else "time"
        t = ds.variables[tname]
        out["time"] = pd.to_datetime(netCDF4.num2date(t[:], t.units, only_use_cftime_datetimes=False))
        out["lat"] = np.ma.filled(ds.variables["latitude"][:], np.nan).astype(float)
        out["lon"] = ((np.ma.filled(ds.variables["longitude"][:], np.nan) + 180) % 360) - 180
        for k in ("u10", "v10", "swh", "shts", "mwd", "mwp"):
            if k in ds.variables:
                out[k] = np.ma.filled(ds.variables[k][:], np.nan).astype(float)
    return out


def sample(era, lat, lon, when):
    # nearest hour and nearest grid point; adds wind speed
    ti = int(np.argmin(np.abs(era["time"] - pd.Timestamp(when))))
    i = np.abs(era["lat"][None, :] - np.asarray(lat)[:, None]).argmin(1)
    j = np.abs(era["lon"][None, :] - np.asarray(lon)[:, None]).argmin(1)
    out = {k: era[k][ti][i, j] for k in ("u10", "v10", "swh", "shts", "mwd", "mwp") if k in era}
    if "u10" in out:
        out["wind"] = np.hypot(out["u10"], out["v10"])
    return pd.DataFrame(out)
