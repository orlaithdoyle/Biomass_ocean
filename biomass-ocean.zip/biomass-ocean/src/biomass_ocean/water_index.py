import numpy as np

from .utils import block_mean, nan_uniform, nan_uniform_complex, wrap

# BIOMASS-only fresh/salt index (Step 19b). No SSS input.
# On its own it tracks along-track structure that salinity and sea state share; see ablation.partial_r


def _col_detrend(x):
    return x - np.nanmedian(x, axis=0, keepdims=True)


def _col_detrend_phase(phi):
    c = np.angle(np.nanmean(np.exp(1j * phi), axis=0, keepdims=True))
    return wrap(phi - c)


def _z(x):
    return (x - np.nanmean(x)) / np.nanstd(x)


def water_index(hh, vv, az=6, rg=1, smooth=5, coh_min=0.3, vv_pct=5):
    # hh, vv: single-look complex, land already NaN. az:rg chosen so the multilooked pixel is ~square on ground
    i_hh = block_mean(np.abs(hh) ** 2, az, rg)
    i_vv = block_mean(np.abs(vv) ** 2, az, rg)
    x = block_mean(hh * np.conj(vv), az, rg)
    xs = nan_uniform_complex(x, smooth)
    ratio = nan_uniform(_col_detrend(10 * np.log10(i_hh / i_vv)), smooth)
    cpd = _col_detrend_phase(np.angle(xs))
    coh = np.abs(xs) / np.sqrt(nan_uniform(i_hh, smooth) * nan_uniform(i_vv, smooth))
    idx = (_z(ratio) - _z(cpd)) / np.sqrt(2)
    vv_db = 10 * np.log10(i_vv)
    unclear = (coh < coh_min) | (vv_db < np.nanpercentile(vv_db, vv_pct)) | ~np.isfinite(idx)
    cls = np.zeros(idx.shape, np.int8)  # 0 neutral, 1 fresh, -1 salt, -9 unclear
    cls[idx > 1] = 1
    cls[idx < -1] = -1
    cls[unclear] = -9
    return dict(index=idx, cls=cls, ratio_db=ratio, cpd=cpd, coherence=coh, vv_db=vv_db)
