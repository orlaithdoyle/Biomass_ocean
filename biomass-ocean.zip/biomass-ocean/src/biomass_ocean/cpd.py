from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import rasterio
from rasterio.windows import Window
from tqdm.auto import tqdm

from . import product as prod
from .landmask import is_ocean
from .utils import circ_mean, savefig

CHUNK = 2000
DEC = 2
CMAP = "gist_rainbow"


def cpd_single_look(pdir, dec=DEC, chunk=CHUNK, progress=True):
    # single-look wrapped HH-VV phase, no multilook, no smoothing; decimation is for display only
    amp_t, pha_t = prod.tiffs(pdir)
    oa, op = prod.band_order(amp_t), prod.band_order(pha_t)
    h, w = prod.shape(pha_t)
    out = []
    with rasterio.open(amp_t) as sa, rasterio.open(pha_t) as sp:
        for r0 in tqdm(range(0, h, chunk), desc=Path(pdir).name[-30:], disable=not progress, leave=False):
            n = min(chunk, h - r0)
            win = Window(0, r0, w, n)
            off = (-r0) % dec
            a_hh = sa.read(oa["HH"], window=win)[off::dec, ::dec]
            a_vv = sa.read(oa["VV"], window=win)[off::dec, ::dec]
            p_hh = sp.read(op["HH"], window=win)[off::dec, ::dec].astype(np.float64)
            p_vv = sp.read(op["VV"], window=win)[off::dec, ::dec].astype(np.float64)
            phi = np.angle(np.exp(1j * (p_hh - p_vv)))
            bad = ~np.isfinite(a_hh) | ~np.isfinite(a_vv) | (a_hh == 0) | (a_vv == 0) | ~np.isfinite(phi)
            phi[bad] = np.nan
            out.append(phi.astype(np.float32))
    return np.vstack(out)


def north_up(arr, lat, lon):
    # flip so north is at the top and west on the left, whatever the pass direction
    flip_ud = np.nanmean(np.diff(np.nanmean(lat, axis=1))) > 0
    flip_lr = np.nanmean(np.diff(np.nanmean(lon, axis=0))) < 0
    f = lambda x: x[::-1] if flip_ud else x
    g = lambda x: x[:, ::-1] if flip_lr else x
    return [g(f(a)) for a in (arr, lat, lon)]


def ocean_cpd(pdir, dec=DEC, chunk=CHUNK, progress=True):
    pdir = Path(pdir)
    phi = cpd_single_look(pdir, dec, chunk, progress)
    amp_t, _ = prod.tiffs(pdir)
    lat, lon = prod.latlon_grid(amp_t, dec=dec)
    lat, lon = lat[: phi.shape[0], : phi.shape[1]], lon[: phi.shape[0], : phi.shape[1]]
    phi[~is_ocean(lat, lon)] = np.nan
    phi, lat, lon = north_up(phi, lat, lon)
    d = prod.info(pdir)
    d.update(phi=phi, lat=lat, lon=lon)
    return d


def colour_limits(phi):
    # mean +- 1 ordinary std, after centring on the circular mean so the +-pi wrap can't inflate it
    v = phi[np.isfinite(phi)]
    c = circ_mean(v)
    d = np.angle(np.exp(1j * (v - c)))
    s = float(np.std(d))
    return float(c), s, (c - s, c + s)


def _cmap():
    return plt.get_cmap(CMAP).with_extremes(bad="white")


def plot_product(res, out_dir, show=True):
    phi, lat, lon = res["phi"], res["lat"], res["lon"]
    if not np.isfinite(phi).any():
        print("no ocean pixels in", res["path"].name)
        return None
    c, s, (vmin, vmax) = colour_limits(phi)
    tag = f"{res['date'].replace('-', '')}_T{res['track']:03d}_F{res['frame']:03d}"
    fig, (ax, axh) = plt.subplots(1, 2, figsize=(12, 7), gridspec_kw=dict(width_ratios=[2, 1]))
    ext = [np.nanmin(lon), np.nanmax(lon), np.nanmin(lat), np.nanmax(lat)]
    im = ax.imshow(phi, cmap=_cmap(), vmin=vmin, vmax=vmax, extent=ext, aspect="auto", interpolation="nearest")
    ax.set_xlabel("Longitude (°)")
    ax.set_ylabel("Latitude (°)")
    ax.set_title(f"HH-VV phase, {res['date']} T{res['track']:03d} F{res['frame']:03d} {res.get('orbit_pass') or ''}")
    fig.colorbar(im, ax=ax, label="HH-VV phase (rad)")
    v = phi[np.isfinite(phi)]
    axh.hist(v, bins=200, color="0.4")
    axh.axvspan(vmin, vmax, color="gold", alpha=0.3, label=f"±1σ = {s:.3f} rad")
    axh.axvline(c, ls="--", color="k", label=f"mean {c:.3f} rad")
    axh.set_xlabel("HH-VV phase (rad)")
    axh.legend()
    fig.tight_layout()
    out = Path(out_dir)
    savefig(fig, out / f"cpd_singlelook_{tag}.png")
    np.savez_compressed(out / f"cpd_singlelook_{tag}.npz", phi=phi, lat=lat, lon=lon, mean=c, std=s)
    if show:
        plt.show()
    else:
        plt.close(fig)
    return out / f"cpd_singlelook_{tag}.png"


def load_npz(path):
    z = np.load(path)
    return {k: z[k] for k in z.files}
