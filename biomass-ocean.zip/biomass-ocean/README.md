# biomass-ocean

Code for looking at ESA BIOMASS P-band SAR (L1a SCS) over the ocean: getting the data from MAAP, HH-VV phase (CPD) maps per product and per pass, comparison with SMOS/SMAP sea surface salinity, the ablation and sea-state controls used to test that comparison, a full-catalogue swath scanner, and the wave/Bragg models.

Written during an ESA ESTEC internship on BIOMASS (May to October 2026).
Orlaith Doyle (Ní Dhúill), supervised by Björn Rommen.

## Layout

```
src/biomass_ocean/
  auth.py          MAAP offline token -> short-lived access token
  search.py        STAC search of BiomassLevel1a, product ID parsing
  download.py      download assets, skips what is already on disk
  product.py       find products, band order from tags, GCP geolocation, orbit pass, quality flag
  landmask.py      ocean/land from global_land_mask
  cpd.py           single-look HH-VV phase per product, plot + npz
  mosaic.py        group frames into passes, per-pass strips
  sss.py           SMOS/SMAP loading, 0.25 deg cell table
  era5.py          ERA5 wind / waves download and sampling
  ablation.py      leave-one-pass-out regression, ablation, partial r, null tests
  water_index.py   BIOMASS-only fresh/salt index (HH/VV ratio and CPD)
  scanner.py       resumable full-catalogue swath scan and ocean/coastal/land classes
  dielectric.py    Klein-Swift permittivity, Fresnel and Bragg coefficients
  waves.py         Elfouhaily spectrum, (tilted) Bragg sigma0, image and cross spectra
  utils.py         NaN-safe filters, multilook, circular stats
notebooks/
  00_setup_and_login        package check, token test
  01_search_and_download    search by place or ID, download, QC table
  02_cpd_single_product     one product, HH-VV phase map + histogram
  03_cpd_pass_mosaic        per-pass strips
  04_sss_validation         SMOS/SMAP + ERA5, cell table
  05_ablation_and_water_index
  06_swath_scanner
  07_waves
tests/                      synthetic products, pytest
```

The notebooks are short starter cells. Each one begins with the same cell that sets `DATA_DIR`, `OUT_DIR` and `CREDS`; edit those and run top to bottom.

## Install

```
conda env create -f environment.yml
conda activate biomass-ocean
```

or into an existing environment: `pip install -e ".[validation,dev]"`. Use conda-forge rasterio if you can, the BIOMASS tiffs are LERC compressed and need a GDAL build that supports it.

Credentials: copy `eo_credentials.example.txt` to `eo_credentials.txt` and paste your offline token from the MAAP portal. The file is in `.gitignore`. The token expires after 90 days or a period of inactivity, and the first sign is a 401. SMAP needs a NASA Earthdata login (earthaccess), ERA5 needs `~/.cdsapirc`.

Check everything works without any data: `pytest`.

## HH-VV phase, how it is done here

One fixed method, used for every map:

- per product, single look: `np.angle(np.exp(1j*(p_hh - p_vv)))` from the i_phase tiff, read in 2000-row windows
- polarisation order read from the POLARIMETRIC_INTERP band tags (the tiffs are HH, HV, VH, VV, but never hard-code it)
- pixels with zero or non-finite amplitude removed, decimated by 2 for display only
- land masked from lat/lon interpolated off the GCPs, image flipped north-up, west-left
- colour limits = circular mean ± 1 ordinary std (`np.std` after centring on the circular mean), gist_rainbow, land white
- frames processed individually, then drawn together as a pass

## Things that cost time before

- Server-side `product:type` filters on the STAC silently drop S2/S3 acquisitions. Filter client side.
- STAC queries stop at 100k records and the generator just ends. The scanner works month by month.
- `client_secret` must be sent with the refresh token or you get 401 unauthorized_client.
- `np.array(masked, dtype=float)` on netCDF data keeps the fill values. Use `np.ma.filled(..., np.nan)`.
- `uniform_filter` on masked ocean spreads NaN and inflates edges. Use `utils.nan_uniform`.
- Average phase as complex exponentials, never linearly.
- Descending passes come out mirrored if corner order is assumed. Orientation here comes from the lat/lon grid.
- Quality: `overallProductQualityIndex` bits 5, 10, 11 must be clear. `residualIonosphericPhaseScreenStd` is not a quality flag.

## A note on the SSS comparison

Within-pass skill against SMOS in the Amazon plume came from ERA5 swell and position along track, not from the radar: the same regression with radar inputs alone gives no skill, and the BIOMASS-only index loses its correlation with SSS once along-track position and sea state are controlled. `ablation.py` and notebook 05 exist so that any new result gets the same test. The circular-shift null alone does not catch smooth along-track proxies. A repeat-pass test at fixed locations would separate salinity from geography and has not been done yet.

## Status

The processing, plotting, cell table, ablation, water index and wave code is tested on synthetic products (`tests/`). The MAAP token, STAC search and download functions follow the MAAP documentation but were not run against the live service from the machine this was packaged on, so check notebook 00 first. SMOS variable names differ between CATDS and BEC files; set them in `sss.SOURCES`.
