import numpy as np
import pandas as pd
import pytest

from synthetic import make_product, name_for, make_sss_grid
from biomass_ocean import product as prod, cpd, mosaic, sss, ablation, water_index, waves, search, auth
from biomass_ocean.utils import nan_uniform, block_mean, circ_mean


@pytest.fixture
def products(tmp_path):
    # open Atlantic off the Amazon mouth, two frames of one pass + a descending one
    a = make_product(tmp_path, name_for("2026-07-06", 21, 101), 3.0, -47.5, cpd_rad=0.05)
    b = make_product(tmp_path, name_for("2026-07-06", 21, 102), 4.6, -47.5, cpd_rad=0.05, seed=1)
    c = make_product(tmp_path, name_for("2026-07-07", 36, 50), 3.0, -47.0, ascending=False, seed=2, quality=1 << 10)
    return tmp_path, [a, b, c]


def test_parse_id():
    d = search.parse_id("BIO_S1_SCS__1S_20251121T032348_20251121T032408_T_G01_M01_C01_T003_F007_01_DJUOOI")
    assert d["swath"] == "S1" and d["track"] == 3 and d["frame"] == 7 and d["date"] == "2025-11-21"
    assert search.bbox_around(0, 359) == [-3.0, -2.0, 1.0, 2.0]


def test_credentials(tmp_path):
    f = tmp_path / "eo_credentials.txt"
    f.write_text("maap_offline_token=abc\nmaap_client_id=offline-token\nMAAP_CLIENT_SECRET = 'xyz'\n")
    assert auth.read_credentials(f) == dict(offline_token="abc", client_id="offline-token", client_secret="xyz")


def test_product_meta(products):
    root, (a, b, c) = products
    found = prod.find_products(root)
    assert len(found) == 3
    amp, pha = prod.tiffs(a)
    assert prod.band_order(pha) == {"HH": 1, "HV": 2, "VH": 3, "VV": 4}
    assert prod.orbit_pass(a) == "Ascending" and prod.orbit_pass(c) == "Descending"
    assert prod.quality_ok(a) is True and prod.quality_ok(c) is False
    lat, lon = prod.latlon_grid(amp, dec=2)
    assert lat.shape == (200, 60)
    assert abs(lat[0, 0] - 3.0) < 1e-3 and abs(lon[0, -1] - (-47.5 + 118 * 0.004)) < 1e-3


def test_cpd_and_plot(products, tmp_path):
    root, (a, b, c) = products
    r = cpd.ocean_cpd(a, dec=2, progress=False)
    phi = r["phi"]
    assert phi.shape == (200, 60)
    # north up: latitude decreases down the rows
    assert r["lat"][0, 0] > r["lat"][-1, 0]
    m, s, lims = cpd.colour_limits(phi)
    assert abs(m - 0.05) < 0.02  # recovers the injected HH-VV offset
    assert 0.3 < s < 0.6
    # descending product also comes out north-up
    rc = cpd.ocean_cpd(c, dec=2, progress=False)
    assert rc["lat"][0, 0] > rc["lat"][-1, 0]
    png = cpd.plot_product(r, tmp_path / "out", show=False)
    assert png.exists() and png.with_suffix(".npz").exists()


def test_chunking_matches(products):
    root, (a, *_ ) = products
    full = cpd.cpd_single_look(a, dec=2, chunk=10_000, progress=False)
    chunked = cpd.cpd_single_look(a, dec=2, chunk=37, progress=False)  # odd chunk keeps decimation phase
    assert np.allclose(full, chunked, equal_nan=True)


def test_mosaic_and_cells(products, tmp_path):
    root, _ = products
    passes = mosaic.group_passes(prod.find_products(root))
    key = ("2026-07-06", 21, "S1")
    assert key in passes and len(passes[key]) == 2
    res = mosaic.process_pass(passes[key], dec=2)
    assert mosaic.plot_pass(res, tmp_path / "out", show=False).exists()
    df = sss.cell_table(res, make_sss_grid(), cell=0.25, min_pix=20)
    assert len(df) > 4 and df["sss"].notna().all() and "along_km" in df
    assert df["along_km"].is_monotonic_increasing or df.sort_values("lat")["along_km"].is_monotonic_increasing


def test_ablation_detects_proxy():
    # SSS driven by latitude; a "radar" feature of pure noise must not get skill, latitude must
    rng = np.random.default_rng(0)
    rows = []
    for p in range(10):
        lat = np.linspace(0, 3, 40) + rng.normal(0, 0.05, 40)
        s = 30 + 2 * lat + rng.normal(0, 0.5, 40) + rng.normal(0, 2)
        rows.append(pd.DataFrame(dict(pass_id=f"p{p}", lat=lat, sss=s, radar=rng.normal(size=40),
                                      swell=lat * 0.8 + rng.normal(0, 0.1, 40), along_km=lat * 111)))
    df = pd.concat(rows, ignore_index=True)
    tab = ablation.ablation(df, {"radar": ["radar"], "lat": ["lat"], "swell": ["swell"]})
    t = tab.set_index("set")
    assert t.loc["radar", "skill"] < 0.05
    assert t.loc["lat", "skill"] > 0.5 and t.loc["lat", "passes_improved"] == 10
    r, n = ablation.partial_r(df, "radar", "sss", controls=["along_km"])
    assert abs(r) < 0.15
    r2, _ = ablation.partial_r(df, "swell", "sss")
    r3, _ = ablation.partial_r(df, "swell", "sss", controls=["lat"])
    assert r2 > 0.7 and abs(r3) < 0.2
    obs, ci, p = ablation.shuffle_null(df, "radar", "sss", n=100)
    assert p > 0.05
    assert (ablation.proxy_check(df, "swell", "lat")["r"] > 0.9).all()


def test_water_index():
    rng = np.random.default_rng(0)
    h, w = 240, 60
    hh = (rng.normal(size=(h, w)) + 1j * rng.normal(size=(h, w))) / np.sqrt(2)
    vv = 0.9 * hh + 0.3 * (rng.normal(size=(h, w)) + 1j * rng.normal(size=(h, w)))
    vv[:20] = np.nan
    out = water_index.water_index(hh, vv, az=6, rg=1, smooth=3)
    assert out["index"].shape == (40, 60)
    assert set(np.unique(out["cls"])) <= {-9, -1, 0, 1}


def test_utils():
    x = np.ones((20, 20))
    x[:, :5] = np.nan
    y = nan_uniform(x, 5)
    assert np.allclose(y[:, 5:], 1)  # no NaN bleed, no edge inflation
    assert block_mean(np.arange(16.0).reshape(4, 4), 2, 2).shape == (2, 2)
    assert abs(circ_mean(np.array([np.pi - 0.1, -np.pi + 0.1])) ) > 3


def test_waves():
    eps = waves.klein_swift(35, 20)
    assert 70 < eps.real < 75 and eps.imag < -150
    hh, vv, cpd_ = waves.bragg_sigma0(35, 7)
    assert vv > hh and 0 < np.degrees(cpd_) < 5
    rng = np.random.default_rng(0)
    y, x = np.mgrid[0:256, 0:256] * 10.0
    img = 1 + 0.3 * np.cos(2 * np.pi * (x * np.cos(0.5) + y * np.sin(0.5)) / 200) + 0.05 * rng.normal(size=x.shape)
    kx, ky, P = waves.image_spectrum(img, 10, 10)
    pk = waves.spectral_peak(kx, ky, P)
    assert abs(pk["wavelength_m"] - 200) < 20


def test_download_paths():
    from biomass_ocean import download
    href = ("https://catalog.maap.eo.esa.int/data/biomass-pdgs-01/BiomassLevel1a/2025/11/21/"
            "BIO_S1_SCS__1S_20251121T032348_20251121T032408_T_G01_M01_C01_T003_F007_01_DJUOOI/"
            "BIO_S1_SCS__1S_20251121T032348_20251121T032408_T_G01_M01_C01_T003_F007_01_DJUOOI/measurement/x_i_phase.tiff")
    p = download.local_path(href, "data")
    assert p.parts[1].startswith("BIO_S1_SCS") and p.parts[-2:] == ("measurement", "x_i_phase.tiff")
