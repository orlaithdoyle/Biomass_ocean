from pathlib import Path
import numpy as np
import rasterio
from rasterio.control import GroundControlPoint
from rasterio.crs import CRS

ORDER = ["HH", "HV", "VH", "VV"]


def make_product(root, name, lat0, lon0, h=400, w=120, dlat=0.004, dlon=0.004, ascending=True,
                 cpd_rad=0.05, seed=0, quality=0):
    # small fake SCS product: i_abs / i_phase tiffs with band tags + GCPs, and an annotation xml
    rng = np.random.default_rng(seed)
    p = Path(root) / name / name
    (p / "measurement").mkdir(parents=True, exist_ok=True)
    (p / "annotation").mkdir(exist_ok=True)
    gcps = []
    for r in np.linspace(0, h - 1, 6):
        for c in np.linspace(0, w - 1, 4):
            lat = lat0 + (r * dlat if ascending else (h - 1 - r) * dlat)
            lon = lon0 + c * dlon
            gcps.append(GroundControlPoint(row=r, col=c, x=lon, y=lat, z=0))
    amp = rng.rayleigh(1.0, (4, h, w)).astype(np.float32)
    amp[:, :5, :5] = 0  # invalid corner
    base = rng.uniform(-np.pi, np.pi, (h, w))
    pha = np.stack([base + rng.normal(0, 0.3, (h, w)) for _ in range(4)]).astype(np.float32)
    pha[0] = base + cpd_rad + rng.normal(0, 0.3, (h, w))  # HH
    pha[3] = base + rng.normal(0, 0.3, (h, w))            # VV
    pha = np.angle(np.exp(1j * pha)).astype(np.float32)
    for kind, data in (("abs", amp), ("phase", pha)):
        f = p / "measurement" / f"{name.lower()}_i_{kind}.tiff"
        with rasterio.open(f, "w", driver="GTiff", height=h, width=w, count=4, dtype="float32",
                           gcps=gcps, crs=CRS.from_epsg(4326)) as dst:
            for b in range(4):
                dst.write(data[b], b + 1)
                dst.update_tags(b + 1, POLARIMETRIC_INTERP=ORDER[b])
    (p / "annotation" / f"{name.lower()}_annot.xml").write_text(
        f"<root><sarImage><orbitPass>{'Ascending' if ascending else 'Descending'}</orbitPass></sarImage>"
        f"<quality><overallProductQualityIndex>{quality}</overallProductQualityIndex></quality></root>"
    )
    return p


def name_for(date, track, frame, swath="S1"):
    d = date.replace("-", "")
    return f"BIO_{swath}_SCS__1S_{d}T090000_{d}T090021_T_G01_M01_C01_T{track:03d}_F{frame:03d}_01_ABCDEF"


def make_sss_grid(lat0=-1, lat1=6, lon0=-52, lon1=-44, res=0.25):
    lat = np.arange(lat0, lat1, res) + res / 2
    lon = np.arange(lon0, lon1, res) + res / 2
    LA, LO = np.meshgrid(lat, lon, indexing="ij")
    sss = 36 - 8 * np.exp(-((LO + 48.5) ** 2 + (LA - 3) ** 2) / 2)
    return dict(sss=sss, lat=lat, lon=lon, source="synthetic", path="")
